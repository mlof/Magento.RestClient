﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AgileObjects.AgileMapper;
using AgileObjects.AgileMapper.Extensions;
using ExcelDataReader;
using Magento.RestClient.Abstractions;
using Magento.RestClient.Configuration;
using Magento.RestClient.Context;
using Magento.RestClient.Data.Models.Common;
using Magento.RestClient.Data.Models.EAV.Attributes;
using Magento.RestClient.Data.Models.Stock;
using Magento.RestClient.Domain.Abstractions;
using Magento.RestClient.Domain.Models.Catalog;
using Magento.RestClient.Domain.Models.EAV;
using Magento.RestClient.Extensions;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using NPOI.OpenXml4Net.OPC;
using NPOI.SS.UserModel;
using Serilog;

namespace Magento.RestClient.Integration
{
	public class FixtureLoader
	{
		private readonly DataSet dataset;

		public static Task Main(string[] args)
		{
			System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

			var loader = new FixtureLoader();


			return loader.Execute();
		}

		private async Task Execute()
		{
			/*
			await DownloadImages();
			await SyncAttributes();
			*/
			//await SyncBrands();

			await SyncProducts();
		}


		async private Task SyncProducts()
		{
			var products = dataset.Tables["Products"];
			var models = new List<IProductModel>();
			for (var index = 0; index < 100; index++)
			{
				//products.Rows.Count; 
				DataRow row = products.Rows[index];
				var sku = Clean(row["Sku"]);

				var product = new ProductModel(this.Context, sku) {
					Price = Convert.ToDecimal(row["Price"] as double? ?? 0),
					Name = row["Name"] as string,
					UrlKey = sku,
					ShortDescription = row["Description"] as string,
					StockItem = new StockItem() {IsInStock = true, Qty = Convert.ToInt32(row["StockQuantity"])},
					["brand"] = row["Brand"] as string
				};
				if (row["Image"] is string productImage && !string.IsNullOrWhiteSpace(productImage))
				{
					await product.AddMediaEntryFromUri(new Uri(productImage)).ConfigureAwait(false);
				}

				models.Add(product);
			}

			await this.Context.CreateOrUpdate(models).ConfigureAwait(false);
		}

		private string Clean(object rowValue)
		{
			return Convert.ToString(rowValue)
				?.Replace("\\", "-")
				.Replace(" ", "-")
				.Replace("/", "-");
		}

		async private Task SyncAttributes()
		{
		}

		async private Task SyncBrands()
		{
			var brands = dataset.Tables["Brands"];


			var brandModel = new AttributeModel(Context, "brand") {
				FrontendInput = AttributeFrontendInput.Select, DefaultFrontendLabel = "Brand"
			};

			var options = new List<string>();
			foreach (DataRow row in brands.Rows)
			{
				var name = row["Name"] as string;

				options.Add(name);
			}

			brandModel.Options = options;

			await brandModel.SaveAsync().ConfigureAwait(false);
		}

		public FixtureLoader()
		{
			Serilog.Log.Logger = new LoggerConfiguration().WriteTo.Console().CreateLogger();
			this.Context = new MagentoAdminContext(new MagentoClientOptions("https://magento.test", "mlof",
				"The quick brown f0x.", AuthenticationMethod.Admin));
			using var stream = File.Open(Path.Join("Fixtures", "Fixtures.xlsx"), FileMode.Open, FileAccess.Read);
			using var reader = ExcelReaderFactory.CreateReader(stream);
			this.dataset = reader.AsDataSet(
				new ExcelDataSetConfiguration() {
					ConfigureDataTable = (_) => new ExcelDataTableConfiguration() {UseHeaderRow = true}
				}
			);
		}

		public IAdminContext Context {
			get;
			set;
		}
	}
}